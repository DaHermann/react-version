import img1 from "../../../assets/img/pages/graphic-1.png"
import img2 from "../../../assets/img/pages/graphic-2.png"
import img3 from "../../../assets/img/pages/graphic-3.png"
import img4 from "../../../assets/img/pages/graphic-4.png"
import img5 from "../../../assets/img/pages/graphic-5.png"
import img6 from "../../../assets/img/pages/graphic-6.png"

export const data = [
  {
    id: 1,
    img: img1,
    title: "sales automation",
    text: "Muffin lemon drops chocolate carrot cake chocolate bar sweet roll."
  },
  {
    id: 2,
    img: img2,
    title: "marketing automation",
    text: "Gingerbread sesame snaps wafer soufflé. Macaroon brownie ice cream."
  },
  {
    id: 3,
    img: img3,
    title: "marketing bi",
    text:
      "cotton candy caramels danish chocolate cake pie candy. Lemon drops tart.."
  },
  {
    id: 4,
    img: img4,
    title: "personalization",
    text: "Pudding oat cake carrot cake lemon drops gummies marshmallow.."
  },
  {
    id: 5,
    img: img5,
    title: "email marketing",
    text: "Gummi bears pudding icing sweet caramels chocolate.Muffin croissant."
  },
  {
    id: 6,
    img: img6,
    title: "demand generation",
    text: "Dragée jelly beans candy canes pudding cake wafer. Muffin croissant."
  }
]
