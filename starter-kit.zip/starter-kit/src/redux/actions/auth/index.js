import * as loginAction from "./loginActions"
export default loginAction
